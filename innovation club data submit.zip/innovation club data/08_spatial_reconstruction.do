* ==============================================================================
* 08_spatial_reconstruction.do -- Spatial convergence club reconstruction (Sec. 4.6 & Table 5)
* MAPS TO: Table 5 (spatial clubs), Appendix B (spatial club member list), and data for Figure 4
* ------------------------------------------------------------------------------
* Purpose: fuse the Phillips-Sul "growth property" with the inter-city "spatial
*          property" to reconstruct spatial convergence clubs.
*   Step 1: aggregate county coordinates to the centroids of 274 cities; compute
*           spherical distances and nearest-neighbor distances.
*   Step 2: take the 22 cities in clubs <= 6 as candidate growth poles; 250 km
*           spatial deduplication yields 13 growth poles.
*   Step 3: partition radiation domains under the constraint that the growth
*           pole's hierarchy is not lower than its hinterland's.
* Result: 13 spatial clubs (Table 5); growth poles are Beijing, Shenzhen, Shanghai,
*         Wuhan, Chengdu, Hefei, Chongqing, Zhengzhou, Xi'an, Changsha, Qingdao,
*         Jinan, and Kunming.
* Inputs (data_raw/): county_coordinates.xlsx
* Inputs (data/): club_city_assign.dta; panel_cii_2000_2024.dta
* Outputs (data/): spatial_analysis_274cities.dta; spatial_clubs.dta
* Outputs: spatial_clubs.xlsx; appendix_spatial_club_members.md
* Run from the package root.
* ==============================================================================
clear all
set more off

* ================= Step 1: build the 274-city spatial analysis dataset =================
import excel using "data_raw/county_coordinates.xlsx", sheet("Sheet1") firstrow clear
collapse (mean) 经度 纬度, by(地市)
rename (地市 经度 纬度) (city_zh lon lat)
* name corrections (historical renames / naming differences)
replace city_zh = "襄阳市" if city_zh == "襄樊市"
replace city_zh = "菏泽市" if city_zh == "牡丹区"
replace city_zh = "普洱市" if city_zh == "墨江哈尼族自治县"
preserve
    import delimited using "data_raw/city_name_map.csv", varnames(1) clear
    tempfile citymap
    save `citymap'
restore
merge m:1 city_zh using `citymap', keep(match) nogen
gen city = city_en
drop city_zh city_en
tempfile coord
save `coord'

use "data/club_city_assign.dta", clear
preserve
    use "data/panel_cii_2000_2024.dta", clear
    keep if year == 2023
    keep city_id cii
    rename cii cii2023
    tempfile c
    save `c'
restore
merge 1:1 city_id using `c', nogen keep(master match)

merge 1:1 city_id using `coord'
assert _merge != 1                     // all 274 cities must have coordinates
keep if _merge == 3
drop _merge

sort rank
gen id = _n                            // 1..274, in descending order of innovation
order city_id province city id rank club region4 hu_line lon lat cii2023
label variable lon "Longitude (city centroid)"
label variable lat "Latitude (city centroid)"
save "data/spatial_analysis_274cities.dta", replace

* ================= Step 2: spherical distance matrix + nearest-neighbor distance =================
use "data/spatial_analysis_274cities.dta", clear
local N = _N
di _newline "Number of cities N = " `N'

mkmat lon, matrix(LON)
mkmat lat, matrix(LAT)
matrix D = J(`N', `N', 0)
forvalues i = 1/`N' {
    local j0 = `i' + 1
    forvalues j = `j0'/`N' {
        scalar dphi = (LAT[`j',1] - LAT[`i',1]) * _pi / 180
        scalar dlam = (LON[`j',1] - LON[`i',1]) * _pi / 180
        scalar phi1 = LAT[`i',1] * _pi / 180
        scalar phi2 = LAT[`j',1] * _pi / 180
        scalar a = (sin(dphi/2))^2 + cos(phi1)*cos(phi2)*(sin(dlam/2))^2
        scalar a = min(a, 1)
        scalar d = 2 * 6371 * asin(sqrt(a))     // Haversine, km
        matrix D[`i',`j'] = d
        matrix D[`j',`i'] = d
    }
}

gen double nndist = .
forvalues i = 1/`N' {
    scalar nd = 1e10
    forvalues j = 1/`N' {
        if `i' != `j' {
            if D[`i',`j'] < nd scalar nd = D[`i',`j']
        }
    }
    replace nndist = nd if id == `i'
}
di _newline "=== Nearest-neighbor distance (spatial proximity overview) ==="
summarize nndist, detail
count if nndist < 100
di "Share of cities with nearest-neighbor distance < 100 km = " %5.3f (r(N)/`N')

* ================= Step 3: growth-pole identification (club<=6, 250 km dedup) =================
gen byte pole = 0
levelsof id if club <= 6, local(cand)
local poles ""
foreach i of local cand {
    local mind = 99999
    foreach p of local poles {
        local dd = D[`i',`p']
        if `dd' < `mind' local mind = `dd'
    }
    if `mind' >= 250 {
        local poles "`poles'`i' "
        quietly replace pole = 1 if id == `i'
    }
}
count if pole == 1
local npole = r(N)
di _newline "=== Number of growth poles = " `npole' " (dedup threshold 250 km) ==="
list city club rank cii2023 lon lat if pole == 1, noobs

* ================= Step 4: radiation domain partition (hierarchy + spatial nearest) =================
gen long poleid = .
foreach i of numlist 1/`N' {
    if pole[`i'] == 1 {
        quietly replace poleid = `i' if id == `i'
    }
    else {
        local ci = club[`i']
        local bestd = 99999
        local bestp = .
        foreach p of local poles {
            local cp = club[`p']
            if `cp' <= `ci' {                     // growth pole's hierarchy not lower than hinterland
                local dd = D[`i',`p']
                if `dd' < `bestd' {
                    local bestd = `dd'
                    local bestp = `p'
                }
            }
        }
        if `bestp' == . {                          // fallback: nearest growth pole
            foreach p of local poles {
                local dd = D[`i',`p']
                if `dd' < `bestd' {
                    local bestd = `dd'
                    local bestp = `p'
                }
            }
        }
        quietly replace poleid = `bestp' if id == `i'
    }
}

* ================= Step 5: spatial club numbering (growth poles in descending innovation) =================
gen long sc = .
local scno = 0
forvalues i = 1/`N' {
    if pole[`i'] == 1 {
        local scno = `scno' + 1
        quietly replace sc = `scno' if poleid == `i'
    }
}

gen str40 polename = ""
forvalues i = 1/`N' {
    if pole[`i'] == 1 {
        quietly replace polename = city[`i'] if poleid == `i'
    }
}

di _newline "=== Number of cities per spatial club ==="
tab sc
bysort sc: gen N_sc = _N
summarize N_sc
di "Minimum club size = " r(min)

* ================= Step 6: export member lists and save =================
* Member list (Markdown)
preserve
    sort sc id
    gen strL mlist = city
    bysort sc: replace mlist = mlist[_n-1] + ", " + city if _n > 1
    bysort sc: gen byte last = (_n == _N)
    keep if last
    keep sc polename N_sc mlist
    sort sc
    file open fh using "appendix_spatial_club_members.md", write replace
    file write fh "## Appendix: List of Spatial Club Members (growth-spatial integration)" _n _n
    file write fh "> `npole' spatial clubs in total, `N' cities; each club is centered on a growth pole." _n _n
    local nobs = _N
    forvalues i = 1/`nobs' {
        local s = sc[`i']
        local p = polename[`i']
        local n = N_sc[`i']
        local lst = mlist[`i']
        file write fh "**Spatial Club `s'** (`n' cities, growth pole: `p'): `lst'" _n _n
    }
    file close fh
restore

* Excel (one row per city)
preserve
    sort sc id
    keep province city club sc pole polename cii2023 lon lat
    rename (sc pole polename cii2023) (spatial_club is_pole pole_city cii_2023)
    export excel using "spatial_clubs.xlsx", firstrow(varlabels) replace
restore

label variable pole     "Growth pole indicator"
label variable poleid   "Affiliated growth pole id"
label variable sc       "Spatial club number"
label variable polename "Growth pole city"
save "data/spatial_clubs.dta", replace

di _newline "=== Complete: data/spatial_clubs.dta / spatial_clubs.xlsx / appendix_spatial_club_members.md ==="
