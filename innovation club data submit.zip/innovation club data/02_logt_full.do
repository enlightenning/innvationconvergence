* ==============================================================================
* 02_logt_full.do -- Full-sample log-t convergence test (Sec. 3.2 & 4.1)
* MAPS TO: Table 2 (full-sample log-t convergence test)
* ------------------------------------------------------------------------------
* Purpose: run the Phillips-Sul (2007) log-t convergence test on the balanced
*          2003-2023 panel.
* Input (data/): panel_cii_2000_2024.dta
* Result: full-sample b_hat = -1.6206, t_b = -69.53 (Table 2), significant divergence.
* Run from the package root.
* ==============================================================================
clear all
set more off
use "data/panel_cii_2000_2024.dta", clear

* ---------- Balanced panel: 2003-2023 (21 years) ----------
keep if year >= 2003 & year <= 2023
bysort city_id: egen nobs = count(cii)
keep if nobs == 21
drop nobs

gen double lncii = ln(cii)

* Number of cities and periods
gen byte first = 0
sort city_id year
by city_id: replace first = (_n == 1)
count if first
local Ncity = r(N)
summarize year
local T = r(max) - r(min) + 1
di _newline "Balanced cities N = " `Ncity' ", periods T = " `T' ", observations = " _N

* ---------- log-t test subroutine ----------
capture program drop logt_sub
program define logt_sub, rclass
    preserve
    bysort year: egen double mean_ln = mean(lncii)
    gen double h = lncii / mean_ln                  // relative transition coefficient
    gen double hdev2 = (h - 1)^2
    bysort year: egen double H_t = mean(hdev2)      // cross-sectional variance
    collapse (mean) H_t, by(year)
    sort year
    gen t = _n
    summarize H_t if t == 1
    local H1 = r(mean)
    gen double lhs = ln(`H1'/H_t) - 2*ln(ln(t))     // log(H1/Ht) - 2 log L(t)
    gen double rhs = ln(t)                          // log t
    local T = _N
    local rT = max(2, floor(0.3*`T'))               // discard first 30% of the sample
    reg lhs rhs if t >= `rT'
    local b = _b[rhs]
    local se = _se[rhs]
    restore
    return scalar b  = `b'
    return scalar se = `se'
    return scalar T  = `T'
    return scalar rT = `rT'
end

* ---------- Full-sample test ----------
di _newline "========== Full-sample log-t convergence test =========="
logt_sub
local b  = r(b)
local tb = r(b)/r(se)
di "b_hat  = " %9.4f `b'
di "t_b    = " %9.4f `tb'
di "Regression start rT = " r(rT) " (first 30% discarded)"
if `tb' >= -1.65 {
    di "Conclusion: full-sample convergence (a single convergence club)"
}
else {
    di "Conclusion: full-sample divergence (b_hat < 0, t_b < -1.65); proceed to club clustering"
}
