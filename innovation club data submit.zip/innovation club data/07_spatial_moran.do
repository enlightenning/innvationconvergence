* ==============================================================================
* 07_spatial_moran.do -- Provincial Moran's I spatial autocorrelation (Sec. 4.5)
* MAPS TO: Section 4.5 in-text result (provincial Moran's I = 0.107, p = 0.080)
* ------------------------------------------------------------------------------
* Purpose: build a spatial weight matrix from the land adjacency of 30 provincial
*          units (65 edges) and compute the global Moran's I of 2023 average
*          provincial innovation, with a 999-permutation test.
* Result: Moran's I = 0.107, E(I) = -0.034, permutation p-value = 0.080 (text).
* Inputs (data/): club_city_assign.dta; panel_cii_2000_2024.dta
* Run from the package root.
* ==============================================================================
clear all
set more off
set seed 20260910

* ---------- 1. 2023 average innovation index by province ----------
use "data/club_city_assign.dta", clear
preserve
    use "data/panel_cii_2000_2024.dta", clear
    keep if year == 2023
    keep city_id cii
    tempfile c2023
    save `c2023'
restore
merge m:1 city_id using `c2023', nogen keep(master match)
collapse (mean) cii, by(province)
tempfile prov_cii
save `prov_cii'

* ---------- 2. Fixed province list (pid) merged with cii ----------
clear
input str24 province int pid
"Beijing" 1
"Tianjin" 2
"Hebei" 3
"Shanxi" 4
"Inner Mongolia" 5
"Liaoning" 6
"Jilin" 7
"Heilongjiang" 8
"Shanghai" 9
"Jiangsu" 10
"Zhejiang" 11
"Anhui" 12
"Fujian" 13
"Jiangxi" 14
"Shandong" 15
"Henan" 16
"Hubei" 17
"Hunan" 18
"Guangdong" 19
"Guangxi" 20
"Hainan" 21
"Chongqing" 22
"Sichuan" 23
"Guizhou" 24
"Yunnan" 25
"Shaanxi" 26
"Gansu" 27
"Qinghai" 28
"Ningxia" 29
"Xinjiang" 30
end
merge 1:1 province using `prov_cii', nogen
sort pid
quietly summarize cii
gen double zbar = cii - r(mean)
tempfile prov
save `prov'

* ---------- 3. Provincial land-adjacency edges (65 undirected edges) ----------
clear
input int pid1 int pid2
1 2
1 3
2 3
3 4
3 5
3 6
3 15
3 16
4 5
4 26
4 16
5 6
5 7
5 8
5 26
5 29
5 27
6 7
7 8
9 10
9 11
10 15
10 12
10 11
11 12
11 14
11 13
12 14
12 17
12 16
12 15
13 14
13 19
14 19
14 18
14 17
15 16
16 26
16 17
17 18
17 22
17 26
18 19
18 20
18 24
18 22
19 20
19 21
20 24
20 25
22 26
22 24
22 23
23 28
23 27
23 26
23 24
23 25
24 25
26 27
26 29
27 29
27 28
27 30
28 30
end
local E = _N
matrix W = J(30, 30, 0)
forvalues i = 1/`E' {
    local a = pid1[`i']
    local b = pid2[`i']
    matrix W[`a',`b'] = 1
    matrix W[`b',`a'] = 1
}

* ---------- 4. Observed Moran's I (matrix algebra) ----------
use `prov', clear
sort pid
mkmat zbar, matrix(Z)
matrix Zt = Z'
matrix ZtW = Zt * W
matrix num = ZtW * Z
matrix den = Zt * Z
local numerator = num[1,1]
local denominator = den[1,1]
matrix one = J(1, 30, 1)
matrix ones = J(30, 1, 1)
matrix S = one * W * ones
local S0 = S[1,1]
local N = 30
local Iobs = (`N'/`S0') * `numerator' / `denominator'
di _newline "=== Observed Moran's I ==="
di "N = " `N' "   E(edges) = " `E' "   S0 = " `S0'
di "Moran's I = " %12.6f `Iobs'
di "E[I]      = " %12.6f (-1/(`N'-1))

* ---------- 5. Permutation test (999 permutations) ----------
local B = 999
local count = 0
forval b = 1/`B' {
    preserve
        use `prov', clear
        gen double r = runiform()
        sort r
        mkmat zbar, matrix(Zp)
        matrix Zpt = Zp'
        matrix ZptW = Zpt * W
        matrix nump = ZptW * Zp
        local Ip = (`N'/`S0') * nump[1,1] / `denominator'
        if `Ip' >= `Iobs' local count = `count' + 1
    restore
}
local pval = (`count' + 1) / (`B' + 1)
di _newline "=== Permutation test (B = `B') ==="
di "Number of permutations with I >= I_obs = " `count'
di "p-value (one-tailed) = " %12.4f `pval'
