* ==============================================================================
* 04_club_summary.do -- Club summary table and member lists (Table 3 & Appendix)
* MAPS TO: Table 3 (club summary) and Appendix A (club member list)
* ------------------------------------------------------------------------------
* Purpose: produce the club summary (size, average innovation index, four-region
*          composition, representative cities) and export the full member lists
*          (Excel / CSV / Markdown appendix).
* Inputs (data/): club_city_assign.dta; panel_cii_2000_2024.dta
* Outputs: club_summary.xlsx; club_members.xlsx/.csv; appendix_club_members.md
* Run from the package root.
* ==============================================================================
clear all
set more off
use "data/club_city_assign.dta", clear

* ---------- 1. Merge 2023 innovation index (end-of-sample level) ----------
preserve
    use "data/panel_cii_2000_2024.dta", clear
    keep if year == 2023
    keep city_id cii
    rename cii cii_2023
    tempfile c
    save `c'
restore
merge m:1 city_id using `c', nogen keep(master match)

* ---------- 2. Club-level average innovation index ----------
bysort club: egen double club_mean = mean(cii_2023)

* ---------- 3. Representative cities (top 3 by rank) ----------
sort club rank
by club: gen byte seq = _n
preserve
    keep if seq <= 3
    gen strL rep = city
    by club: replace rep = rep[_n-1] + ", " + city if _n > 1
    by club: keep if _n == _N
    keep club rep
    tempfile rep
    save `rep'
restore

* ---------- 4. Four-region dummies and club-level aggregation ----------
gen byte is_east = (region4 == "East")
gen byte is_mid  = (region4 == "Central")
gen byte is_west = (region4 == "West")
gen byte is_ne   = (region4 == "Northeast")

collapse (count) N = city_id (mean) club_mean ///
         (sum) east = is_east mid = is_mid west = is_west ne = is_ne, by(club)

gen double pct_east = round(east/N*100, 0.1)
gen double pct_mid  = round(mid/N*100, 0.1)
gen double pct_west = round(west/N*100, 0.1)
gen double pct_ne   = round(ne/N*100, 0.1)

merge 1:1 club using `rep', nogen
order club N club_mean east mid west ne pct_east pct_mid pct_west pct_ne rep

label variable club      "Club"
label variable N         "Number of cities"
label variable club_mean "Average innovation index"
label variable pct_east  "East (%)"
label variable pct_mid   "Central (%)"
label variable pct_west  "West (%)"
label variable pct_ne    "Northeast (%)"
label variable rep       "Representative cities"

sort club
di _newline "========== Club summary (Table 3) =========="
format club_mean %9.4f
list club N club_mean pct_east pct_mid pct_west pct_ne rep, noobs

export excel club N club_mean pct_east pct_mid pct_west pct_ne rep ///
    using "club_summary.xlsx", firstrow(varlabels) replace

* ---------- 5. Full member lists ----------
use "data/club_city_assign.dta", clear
preserve
    use "data/panel_cii_2000_2024.dta", clear
    keep if year == 2023
    keep city_id cii
    rename cii cii_2023
    tempfile c2
    save `c2'
restore
merge m:1 city_id using `c2', nogen keep(master match)

order province city club region4 hu_line rank cii_2023
sort club rank
export excel province city club region4 hu_line rank cii_2023 ///
    using "club_members.xlsx", firstrow(varlabels) replace
export delimited province city club region4 hu_line rank cii_2023 ///
    using "club_members.csv", replace

* Markdown appendix
sort club rank
by club: gen N = _N
gen strL clist = city
by club: replace clist = clist[_n-1] + ", " + city if _n > 1
by club: gen byte last = (_n == _N)
keep if last
keep club N clist
sort club
file open fh using "appendix_club_members.md", write replace
file write fh "## Appendix: List of Club Members" _n _n
file write fh "> Sorted by innovation level; 274 prefecture-level and above cities in total. The number of club members is shown in parentheses." _n _n
local nobs = _N
forvalues i = 1/`nobs' {
    local c = club[`i']
    local n = N[`i']
    local lst = clist[`i']
    file write fh "**Club `c'** (`n' cities): `lst'" _n _n
}
file close fh

di _newline "Exported: club_summary.xlsx / club_members.xlsx(.csv) / appendix_club_members.md"
