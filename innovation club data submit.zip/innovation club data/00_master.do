* ==============================================================================
* 00_master.do -- Master runner: reproduce all paper results (one click)
* ------------------------------------------------------------------------------
* Runs do-files 01-08 in the order of the paper to reproduce Tables 1-5 and
* Figures 1-3, and to produce all intermediate data and appendix member lists.
* Figure 4 (spatial club map) is drawn separately by plot_spatial_club_map.py
* (Python); see README.md.
* Requirements: Stata 14 or later (verified on Stata MP 18). Set the working
*               directory to the package root (this file's directory) first.
* ==============================================================================
clear all
set more off

* To auto-switch to this file's directory, uncomment and edit the line below:
* cd "<package-root>"

* ---------- Part 1: data and index construction ----------
do "01_build_panel.do"            // entropy method + comprehensive index cii (Table 1)

* ---------- Part 2: full-sample log-t convergence test ----------
do "02_logt_full.do"              // full-sample b_hat = -1.6206 (Table 2)

* ---------- Part 3: convergence club clustering ----------
do "03_club_clustering.do"        // 15 convergence clubs (Table 3)
do "04_club_summary.do"           // club summary / member lists (appendix)

* ---------- Part 4: Figures 1-3 ----------
do "05_club_figures.do"           // ladder plot / transition paths / regional composition

* ---------- Part 5: spatiotemporal evolution ----------
do "06_evolution.do"              // sub-periods: 14 / 17 clubs (Table 4)

* ---------- Part 6: spatial test and spatial club reconstruction ----------
do "07_spatial_moran.do"          // provincial Moran's I = 0.107 (p = 0.080)
do "08_spatial_reconstruction.do" // 13 spatial convergence clubs (Table 5, appendix)

di _newline "=============================================================="
di "All do-files completed. Run plot_spatial_club_map.py for Figure 4."
di "=============================================================="
