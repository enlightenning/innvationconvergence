## Appendix: List of Club Members

> Sorted by innovation level; 274 prefecture-level and above cities in total. The number of club members is shown in parentheses.

**Club 1** (3 cities): Beijing, Shenzhen, Shanghai

**Club 2** (1 cities): Guangzhou

**Club 3** (1 cities): Suzhou

**Club 4** (2 cities): Hangzhou, Wuhan

**Club 5** (5 cities): Chengdu, Hefei, Chongqing, Nanjing, Zhengzhou

**Club 6** (10 cities): Ningbo, Xi'an, Tianjin, Changsha, Qingdao, Foshan, Jinan, Dongguan, Wuxi, Kunming

**Club 7** (23 cities): Nanchang, Changzhou, Wenzhou, Taiyuan, Shijiazhuang, Harbin, Shenyang, Nantong, Xiamen, Quanzhou, Changchun, Fuzhou, Nanning, Jiaxing, Jinhua, Zhongshan, Weifang, Shaoxing, Dalian, Wuhu, Zhuhai, Guiyang, Huizhou

**Club 8** (8 cities): Yantai, Taizhou, Xuzhou, Guilin, Lanzhou, Ganzhou, Luoyang, Yangzhou

**Club 9** (5 cities): Baoding, Yancheng, Zhenjiang, Shantou, Linyi

**Club 10** (29 cities): Tangshan, Xinxiang, Zibo, Huzhou, Jining, Taizhou, Zhuzhou, Mianyang, Hohhot, Jiangmen, Urumqi, Langfang, Weihai, Jiujiang, Yichang, Xiangtan, Huai'an, Chuzhou, Yichun, Cangzhou, Xiangyang, Suqian, Deyang, Zhangzhou, Zhaoqing, Ji'an, Lianyungang, Fuyang, Shangrao

**Club 11** (14 cities): Haikou, Ma'anshan, Nanyang, Hengyang, Tai'an, Yinchuan, Dezhou, Jingzhou, Xinyang, Bengbu, Lishui, Shangqiu, Zhanjiang, Handan

**Club 12** (60 cities): Anyang, Jiaozuo, Zhumadian, Xingtai, Rizhao, Xuchang, Xianyang, Binzhou, Anqing, Quzhou, Kaifeng, Liuzhou, Pingdingshan, Liaocheng, Qinhuangdao, Yueyang, Heze, Lu'an, Baotou, Dongying, Zunyi, Chenzhou, Shiyan, Huanggang, Huangshi, Changde, Xiaogan, Chaozhou, Xuancheng, Huainan, Yulin, Zhoukou, Ningde, Jieyang, Fuzhou, Sanya, Ordos, Yiyang, Jilin, Longyan, Tongling, Jingmen, Chongzuo, Shaoyang, Zaozhuang, Maoming, Xining, Suzhou, Putian, Yibin, Luzhou, Baoji, Yongzhou, Luohe, Jingdezhen, Huaibei, Xianning, Anshan, Hengshui, Daqing

**Club 13** (42 cities): Sanmenxia, Zhangjiakou, Jinzhou, Nanping, Sanming, Qingyuan, Zhoushan, Xinyu, Puyang, Yulin, Yangjiang, Yuncheng, Baise, Huaihua, Changzhi, Pingxiang, Loudi, Chengde, Beihai, Shaoguan, Chizhou, Zigong, Yuxi, Leshan, Hanzhong, Qujing, Neijiang, Hebi, Ezhou, Dazhou, Bozhou, Yingtan, Wuzhou, Weinan, Huangshan, Mudanjiang, Karamay, Qinzhou, Panzhihua, Suining, Jiamusi, Ya'an

**Club 14** (62 cities): Yingkou, Shanwei, Meizhou, Datong, Fushun, Heyuan, Dandong, Chifeng, Guigang, Anshun, Jincheng, Tianshui, Fuxin, Wuzhong, Benxi, Hechi, Yan'an, Suizhou, Liupanshui, Shizuishan, Yunfu, Linfen, Ulanqab, Tongliao, Ziyang, Jiayuguan, Panjin, Siping, Zhangye, Laibin, Hezhou, Shuozhou, Pingliang, Jinchang, Jiuquan, Qingyang, Baoshan, Lüliang, Ankang, Zhangjiajie, Lijiang, Tieling, Fangchenggang, Liaoyang, Wuwei, Xinzhou, Guang'an, Guangyuan, Baiyin, Zhaotong, Bayannur, Huludao, Chaoyang, Wuhai, Shangluo, Guyuan, Bazhong, Pu'er, Lincang, Dingxi, Tonghua, Liaoyuan

**Club 15** (9 cities): Tongchuan, Jixi, Songyuan, Heihe, Baishan, Shuangyashan, Baicheng, Qitaihe, Yichun

