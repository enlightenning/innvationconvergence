* ==============================================================================
* 05_club_figures.do -- Club figures (Figure 1 / 2 / 3)
* MAPS TO: Figure 1 (club ladder), Figure 2 (transition paths), Figure 3 (regional composition)
* ------------------------------------------------------------------------------
* Figure 1: ladder structure of the clubs (average index declines by club level)
* Figure 2: relative transition paths of representative clubs (1/4/6/9/12/14/15)
* Figure 3: four-region composition of the clubs (100% stacked bars)
* Inputs (data/): club_city_assign.dta; panel_cii_2000_2024.dta
* Outputs (figures/): figure1_club_ladder.png; figure2_transition_paths.png;
*                     figure3_regional_composition.png
* Run from the package root.
* ==============================================================================
clear all
set more off

* ========================= Figure 1: ladder plot =========================
use "data/club_city_assign.dta", clear
preserve
    use "data/panel_cii_2000_2024.dta", clear
    keep if year == 2023
    keep city_id cii
    rename cii cii_2023
    tempfile c
    save `c'
restore
merge m:1 city_id using `c', nogen keep(master match)
bysort club: egen double club_mean = mean(cii_2023)
collapse (mean) club_mean, by(club)
quietly summarize club
local C = r(max)

graph twoway (connected club_mean club, msymbol(O) msize(medlarge) ///
    lwidth(medthick) lcolor(navy) mcolor(navy)), ///
    ytitle("Average comprehensive innovation index") ///
    xtitle("Convergence club (1 = highest level)") ///
    xlabel(1(1)`C') ylabel(, format(%9.3f) angle(horizontal)) ///
    graphregion(color(white)) plotregion(color(white)) scheme(s2color)
graph export "figures/figure1_club_ladder.png", width(2000) replace

* ========================= Figure 2: transition paths =========================
use "data/panel_cii_2000_2024.dta", clear
keep if year >= 2003 & year <= 2023
merge m:1 city_id using "data/club_city_assign.dta", keep(master match) nogen
gen double lncii = ln(cii)
bysort year: egen double mean_ln = mean(lncii)
gen double h = lncii / mean_ln
collapse (mean) h, by(club year)
keep if inlist(club, 1, 4, 6, 9, 12, 14, 15)
replace h = round(h, 0.0001)
tsset club year
xtline h, overlay legend(order(1 "Club 1" 2 "Club 4" 3 "Club 6" ///
    4 "Club 9" 5 "Club 12" 6 "Club 14" 7 "Club 15") rows(1) ///
    symxsize(4) keygap(2) colgap(3)) ///
    xtitle("Year") ytitle("Relative transition parameter h_it", margin(large)) ///
    graphregion(color(white)) plotregion(color(white)) scheme(s2color)
graph export "figures/figure2_transition_paths.png", width(2000) replace

* ========================= Figure 3: four-region composition =========================
use "data/club_city_assign.dta", clear
gen byte e = (region4 == "East")
gen byte m = (region4 == "Central")
gen byte w = (region4 == "West")
gen byte n = (region4 == "Northeast")
collapse (count) N = rank (sum) e m w n, by(club)
gen pe = 100*e/N
gen pm = 100*m/N
gen pw = 100*w/N
gen pn = 100*n/N

graph bar (asis) pe pm pw pn, over(club, label(labsize(small))) stack ///
    legend(order(1 "East" 2 "Central" 3 "West" 4 "Northeast") rows(1) size(small)) ///
    ytitle("Share of club (%)") ///
    bar(1, color(steelblue)) bar(2, color(gs10)) ///
    bar(3, color(orange_red)) bar(4, color(cranberry)) ///
    graphregion(color(white)) plotregion(color(white)) scheme(s2color)
graph export "figures/figure3_regional_composition.png", width(2000) replace

di _newline "Exported figures/figure1_club_ladder.png, figure2_transition_paths.png, figure3_regional_composition.png"
