* ==============================================================================
* 03_club_clustering.do -- Convergence club clustering (Sec. 3.3 & 4.2)
* MAPS TO: Table 3 (convergence club identification, 15 clubs)
* ------------------------------------------------------------------------------
* Purpose: given full-sample divergence, endogenously identify convergence clubs
*          with the Phillips-Sul (2007) clustering algorithm: sort -> core club
*          formation -> sieving (c* = 0) -> merging adjacent clubs.
* Input (data/): panel_cii_2000_2024.dta
* Output (data/): club_city_assign.dta (274 cities x club; 15 clubs)
* Run from the package root.
* ==============================================================================
clear all
set more off

* ---------- 1. Data: balanced panel, sorted by 2023 innovation level ----------
use "data/panel_cii_2000_2024.dta", clear
keep if year >= 2003 & year <= 2023
bysort city_id: egen nobs = count(cii)
keep if nobs == 21
drop nobs
gen double lncii = ln(cii)

sort city_id year
preserve
    keep if year == 2023
    gsort -lncii
    gen rank = _n                          // 1 = highest innovation level
    keep city_id rank
    tempfile rf
    save `rf', replace
restore
merge m:1 city_id using `rf', nogen
gen club = 0

* ---------- 2. log-t test subroutine ----------
capture program drop logt2
program define logt2, rclass
    preserve
    keep if `1' == 1
    bysort year: egen double mean_ln = mean(lncii)
    gen double h = lncii / mean_ln
    gen double hdev2 = (h - 1)^2
    bysort year: egen double H_t = mean(hdev2)
    collapse (mean) H_t, by(year)
    sort year
    gen t = _n
    summarize H_t if t == 1
    local H1 = r(mean)
    gen double lhs = ln(`H1'/H_t) - 2*ln(ln(t))
    gen double rhs = ln(t)
    local T = _N
    local rT = max(2, floor(0.3*`T'))
    reg lhs rhs if t >= `rT'
    local b = _b[rhs]
    local se = _se[rhs]
    restore
    return scalar b  = `b'
    return scalar se = _se[rhs]
    return scalar tb = `b'/`se'
end

* ---------- 3. Phillips-Sul core clustering ----------
local clubno = 0
local safety = 100
while `safety' > 0 {
    local safety = `safety' - 1
    levelsof rank if club == 0, local(ranks)
    local m = wordcount("`ranks'")
    if `m' == 0 {
        continue, break
    }
    if `m' == 1 {
        local clubno = `clubno' + 1
        local r1 = word("`ranks'", 1)
        replace club = `clubno' if rank == `r1'
        continue, break
    }

    * Core club formation: from the top 2 cities, add until first divergence
    local core_done = 0
    local core_found = 0
    local core_size = 0
    local k = 2
    while `k' <= `m' & `core_done' == 0 {
        local slist = ""
        forval j = 1/`k' {
            local slist = "`slist' " + word("`ranks'", `j')
        }
        gen byte inset = 0
        foreach r in `slist' {
            replace inset = 1 if rank == `r'
        }
        qui logt2 inset
        local tb_k = r(tb)
        drop inset
        if `tb_k' < -1.65 {
            local core_done = 1
            if `k' == 2 {
                local core_found = -1      // top 2 already diverge; the 1st city forms its own club
            }
            else {
                local core_found = 1
                local core_size = `k' - 1
            }
        }
        else {
            local k = `k' + 1
        }
    }
    if `core_done' == 0 {
        local core_found = 1
        local core_size = `m'
    }
    if `core_found' == -1 {
        local clubno = `clubno' + 1
        local r1 = word("`ranks'", 1)
        replace club = `clubno' if rank == `r1'
        continue
    }

    * Assign the core club
    local clubno = `clubno' + 1
    local corelist = ""
    forval j = 1/`core_size' {
        local corelist = "`corelist' " + word("`ranks'", `j')
    }
    foreach r in `corelist' {
        replace club = `clubno' if rank == `r'
    }

    * Sieving: add remaining cities one at a time (criterion c* = 0)
    local j = `core_size' + 1
    while `j' <= `m' {
        local rj = word("`ranks'", `j')
        gen byte inset = 0
        foreach r in `corelist' {
            replace inset = 1 if rank == `r'
        }
        replace inset = 1 if rank == `rj'
        qui logt2 inset
        local tb_s = r(tb)
        drop inset
        if `tb_s' >= 0 {
            replace club = `clubno' if rank == `rj'
            local corelist = "`corelist' `rj'"
        }
        local j = `j' + 1
    }
}

di _newline "========== Core clustering complete =========="
preserve
    collapse (first) rank, by(city_id club)
    quietly summarize club
    di "Initial number of clubs = " r(max)
    tab club
restore

* ---------- 4. Renumber clubs by innovation level (minimum rank) ----------
capture program drop relabel_clubs
program define relabel_clubs
    bysort club: egen double minrank = min(rank)
    preserve
        collapse (min) minrank, by(club)
        gsort minrank
        gen newclub = _n
        keep club newclub
        tempfile relab
        save `relab', replace
    restore
    merge m:1 club using `relab', nogen
    replace club = newclub
    drop newclub minrank
end
relabel_clubs

* ---------- 5. Merge adjacent clubs (criterion -1.65) ----------
local done = 0
local iter = 0
while `done' == 0 & `iter' < 100 {
    local iter = `iter' + 1
    local done = 1
    relabel_clubs
    quietly summarize club
    local C = r(max)
    forval c = 1/`C' {
        local c2 = `c' + 1
        if `c2' <= `C' {
            quietly count if club == `c'
            local n1 = r(N)
            quietly count if club == `c2'
            local n2 = r(N)
            if `n1' > 0 & `n2' > 0 {
                gen byte inset = 0
                replace inset = 1 if club == `c' | club == `c2'
                qui logt2 inset
                local tb_m = r(tb)
                drop inset
                if `tb_m' >= -1.65 {
                    replace club = `c' if club == `c2'
                    local done = 0
                }
            }
        }
    }
}
relabel_clubs

* ---------- 6. Final club results ----------
di _newline "========== Final club identification =========="
preserve
    collapse (first) rank, by(city_id club)
    quietly summarize club
    di "Number of convergence clubs = " r(max)
    tab club
restore

* ---------- 7. Save the assignment (one row per city) ----------
sort city_id year
preserve
    collapse (first) province city region4 hu_line rank club, by(city_id)
    save "data/club_city_assign.dta", replace
restore

di _newline "Saved data/club_city_assign.dta"
