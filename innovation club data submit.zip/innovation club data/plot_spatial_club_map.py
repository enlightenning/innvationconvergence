# -*- coding: utf-8 -*-
"""
Spatial distribution map of urban innovation clubs in China (official base map
plus a South China Sea Islands inset) -- Figure 4 of the paper.
Base map: Alibaba Cloud DataV provincial boundary 100000_full.json
          (including Taiwan, Hainan and the South China Sea Islands with the
          ten-dash line; boundaries unmodified).
Data: data/spatial_clubs.dta (274 city centroids + spatial club membership)
Output: figures/figure4_spatial_clubs.png
"""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import matplotlib.patheffects as pe
import pandas as pd

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans", "Arial"]
plt.rcParams["axes.unicode_minus"] = False

# ---------- read base map ----------
with open("mapdata/100000_full.json", "r", encoding="utf-8") as f:
    geo = json.load(f)

provinces = []
ten_dash = None
for feat in geo["features"]:
    if feat["properties"].get("adcode") == "100000_JD":
        ten_dash = feat
    else:
        provinces.append(feat)


def poly_rings(geom):
    """Return all polygon rings of a feature (each ring is an Nx2 array of lon,lat)."""
    out = []
    t = geom["type"]
    coords = geom["coordinates"]
    if t == "Polygon":
        polys = [coords]
    else:  # MultiPolygon
        polys = coords
    for p in polys:
        for ring in p:
            out.append(np.array(ring)[:, :2])
    return out


def add_polygons(ax, feat, fc, ec, lw, alpha=1.0, z=1):
    for ring in poly_rings(feat["geometry"]):
        ax.add_patch(Polygon(ring, closed=True, facecolor=fc,
                             edgecolor=ec, linewidth=lw, alpha=alpha, zorder=z))


# ---------- read city data ----------
df = pd.read_stata("data/spatial_clubs.dta")

# 13-color palette (Sasha Trubetskoy, first 13 colors)
palette = ["#e6194B", "#3cb44b", "#ffe119", "#4363d8", "#f58231",
           "#911eb4", "#42d4f4", "#f032e6", "#bfef45", "#fabed4",
           "#469990", "#dcbeff", "#9A6324"]

# sc -> growth-pole name (pole cities sorted by sc)
pole_names = df[df["pole"] == 1].sort_values("sc")[["sc", "city"]]
pole_name_map = dict(zip(pole_names["sc"], pole_names["city"]))
pole_coords = df[df["pole"] == 1].sort_values("sc")[["sc", "lon", "lat", "city"]]

# ---------- canvas ----------
fig = plt.figure(figsize=(16, 9.2), dpi=200)
ax = fig.add_axes([0.06, 0.11, 0.72, 0.85])           # main map
ax_inset = fig.add_axes([0.815, 0.16, 0.17, 0.30])    # South China Sea inset

# ============ main map: China + spatial clubs ============
for feat in provinces:
    add_polygons(ax, feat, fc="#f4f0e6", ec="#8a8a8a", lw=0.4, z=1)

# city points (colored by sc)
for s in range(1, 14):
    sub = df[df["sc"] == s]
    ax.scatter(sub["lon"], sub["lat"], s=20, color=palette[s - 1],
               alpha=0.9, edgecolors="white", linewidths=0.2, zorder=3)

# growth poles (large hollow circles with black edge and name)
for _, r in pole_coords.iterrows():
    s = int(r["sc"])
    ax.scatter([r["lon"]], [r["lat"]], s=210, facecolor=palette[s - 1],
               edgecolors="black", linewidths=1.3, zorder=5)
    ax.annotate(r["city"], (r["lon"], r["lat"]),
                xytext=(0, 12), textcoords="offset points", ha="center",
                fontsize=8.5, fontweight="bold", color="black", zorder=6,
                path_effects=[pe.withStroke(linewidth=2.4, foreground="white")])

ax.set_xlim(72, 138)
ax.set_ylim(17, 55)
ax.set_xticks(range(75, 136, 10))
ax.set_yticks(range(20, 56, 10))
ax.tick_params(labelsize=9)
ax.set_xlabel("Longitude (°E)", fontsize=10)
ax.set_ylabel("Latitude (°N)", fontsize=10)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

# legend (13 spatial clubs with growth pole and city count)
handles = []
for s in range(1, 14):
    n = int((df["sc"] == s).sum())
    pname = pole_name_map.get(s, "")
    handles.append(plt.Line2D([0], [0], marker="o", color="w",
                              markerfacecolor=palette[s - 1],
                              markeredgecolor="black", markersize=8,
                              label=f"SC{s} {pname} ({n} cities)"))
ax.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.0, 0.0),
          ncol=2, fontsize=7.5, frameon=True, framealpha=0.95,
          title="Spatial club (growth pole)", title_fontsize=8)

# ============ South China Sea Islands + ten-dash line inset ============
ax_inset.set_facecolor("#f4f0e6")
for feat in provinces:
    if feat["properties"].get("adcode") == "460000":   # Hainan (incl. South China Sea Islands)
        for ring in poly_rings(feat["geometry"]):
            lat_mean = ring[:, 1].mean()
            if lat_mean < 17.0:                         # keep only the South China Sea part
                ax_inset.add_patch(Polygon(ring, closed=True, facecolor="#f4f0e6",
                                           edgecolor="#8a8a8a", linewidth=0.4, zorder=1))
if ten_dash is not None:                                # ten-dash line
    add_polygons(ax_inset, ten_dash, fc="#5a5a5a", ec="#5a5a5a", lw=0.2, z=2)

ax_inset.set_xlim(105, 123)
ax_inset.set_ylim(2, 24.8)
ax_inset.set_xticks([])
ax_inset.set_yticks([])
ax_inset.set_title("South China Sea Islands", fontsize=9, pad=3)
for sp in ax_inset.spines.values():
    sp.set_linewidth(1.0)
    sp.set_color("black")

# ============ title ============
ax.set_title("Spatial clubs of urban innovation in China (growth-spatial integration)",
             fontsize=13, pad=10)

fig.savefig("figures/figure4_spatial_clubs.png", dpi=200, facecolor="white")
print("Saved figures/figure4_spatial_clubs.png")
print("Growth poles:", ", ".join([f"{pole_name_map[s]} (SC{s})" for s in range(1, 14)]))
