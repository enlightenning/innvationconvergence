* ==============================================================================
* 01_build_panel.do -- Data cleaning and comprehensive innovation index (Sec. 3.1)
* MAPS TO: Table 1 (indicator system and entropy weights)
* ------------------------------------------------------------------------------
* Purpose: combine four raw Excel files into a city x year panel and construct the
*          comprehensive urban innovation index (cii) via the entropy method using
*          five positive indicators.
* Inputs (data_raw/):
*   patent_data_2000_2024.xlsx     (sheet "Sheet1")
*   city_database_2000_2024.xlsx   (sheet "线性插值" = linear interpolation)
*   marketization_2000_2024.xlsx   (sheet "原始" = raw)
*   city_name_map.csv / province_name_map.csv   (Chinese-English name maps)
* Outputs (data/): panel_cii_2000_2024.dta
* Notes:
*   - Entropy weights are computed on the FULL sample (2000-2024), consistent with
*     the paper: patent apps 0.2636 / patent grants 0.2678 / S&T exp 0.2838 /
*     college students 0.1599 / marketization 0.0249.
*   - marketization = GDP (10k CNY) / local government general public budget
*     expenditure (10k CNY), as defined in the source file's data note.
*   - The raw spreadsheets carry Chinese column headers and sheet names; they are
*     renamed to English right after import. Raw source data are left unmodified.
* Run from the package root (this file's directory).
* ==============================================================================
clear all
set more off

* ---------- 1. Patent data (innovation output) ----------
import excel using "data_raw/patent_data_2000_2024.xlsx", ///
    sheet("Sheet1") firstrow clear
drop if missing(城市代码)
rename 城市代码 city_id
rename 年份 year
rename 专利申请总量项 pat_app
rename 专利授权总量项 pat_grant
keep city_id year pat_app pat_grant
tempfile pat
save `pat'

* ---------- 2. City database (input + environment + regional information) ----------
import excel using "data_raw/city_database_2000_2024.xlsx", ///
    sheet("线性插值") firstrow clear
drop if missing(城市代码)
rename 城市代码 city_id
rename 年份 year
rename 省份 province_zh
rename 城市 city_zh
rename 所属地域 region_zh
rename 胡焕庸线 hu_line_zh
rename 科学支出万元 sci_exp
rename 户籍人口万人 hukou_pop
rename 普通高等学校在校学生数人 college
keep city_id year province_zh city_zh region_zh hu_line_zh sci_exp hukou_pop college
tempfile city
save `city'

* ---------- 3. Merge patent + city database ----------
use `pat', clear
merge 1:1 city_id year using `city', nogen keep(master match)
drop if missing(province_zh)
drop if city_id == 632500          // drop Sansha (no prefecture-level meaning / missing data)
tempfile base
save `base'

* ---------- 4. Marketization = GDP / general public budget expenditure ----------
import excel using "data_raw/marketization_2000_2024.xlsx", ///
    sheet("原始") firstrow clear
drop if missing(城市代码)
drop if 城市代码 == 632500
rename 城市代码 city_id
rename 年份 year
rename GDP万元 gdp
rename 一般公共预算支出万元 budget_exp
gen double market = gdp / budget_exp
keep city_id year market
tempfile m
save `m'

use `base', clear
merge 1:1 city_id year using `m', keep(master match) nogen

* ---------- 5. Chinese-English name conversion ----------
preserve
    import delimited using "data_raw/city_name_map.csv", varnames(1) clear
    keep city_zh city_en
    tempfile citymap
    save `citymap'
restore
merge m:1 city_zh using `citymap', keep(master match) nogen

preserve
    import delimited using "data_raw/province_name_map.csv", varnames(1) clear
    tempfile provmap
    save `provmap'
restore
merge m:1 province_zh using `provmap', keep(master match) nogen

gen province = province_en
gen city     = city_en

* Four-region classification (East / Central / West / Northeast)
gen region4 = ""
replace region4 = "East"      if region_zh == "东部"
replace region4 = "Central"   if region_zh == "中部"
replace region4 = "West"      if region_zh == "西部"
replace region4 = "Northeast" if inlist(province, "Liaoning", "Jilin", "Heilongjiang")

* Hu Huanyong Line side
gen hu_line = ""
replace hu_line = "Southeast" if hu_line_zh == "东南侧"
replace hu_line = "Northwest" if hu_line_zh == "西北侧"

drop province_zh city_zh region_zh hu_line_zh province_en city_en

* ---------- 6. Entropy method (5 positive indicators) ----------
local inds "pat_app pat_grant sci_exp college market"
local k = 5

* 6.1 Min-max normalization (missing values stay missing)
foreach v of local inds {
    quietly summarize `v'
    gen double z_`v' = (`v' - r(min)) / (r(max) - r(min))
}

* 6.2 Information entropy and weights
matrix W = J(1, `k', .)
local i = 1
foreach v of local inds {
    quietly summarize z_`v'
    local S = r(sum)
    local N = r(N)
    gen double p_`v' = (z_`v' + 1e-10) / (`S' + `k'*1e-10)
    gen double plnp_`v' = p_`v' * ln(p_`v')
    quietly summarize plnp_`v'
    local ent = -r(sum) / ln(`N')
    matrix W[1, `i'] = 1 - `ent'
    local i = `i' + 1
}
matrix colnames W = pat_app pat_grant sci_exp college market
matrix Wn = W / (W[1,1]+W[1,2]+W[1,3]+W[1,4]+W[1,5])
di _newline "========== Entropy weights (5 indicators) =========="
matrix list Wn, format(%9.4f)

* 6.3 Comprehensive innovation index
gen double cii = Wn[1,1]*z_pat_app + Wn[1,2]*z_pat_grant + Wn[1,3]*z_sci_exp ///
              + Wn[1,4]*z_college    + Wn[1,5]*z_market
drop z_* p_* plnp_*

* ---------- 7. Robustness indicator: patent grants per 10,000 persons ----------
gen double pat_grant_pc = pat_grant / hukou_pop * 10000

label variable cii           "Comprehensive innovation index (entropy method)"
label variable market        "Marketization level (GDP / general public budget expenditure)"
label variable pat_grant_pc  "Patent grants per 10,000 persons"
label variable pat_app       "Total patent applications (items)"
label variable pat_grant     "Total patent grants (items)"
label variable sci_exp       "S&T expenditure (10,000 CNY)"
label variable college       "Students enrolled in regular HEIs (persons)"
label variable region4       "Four-region classification (East/Central/West/Northeast)"
label variable hu_line       "Side of the Hu Huanyong Line"

order city_id year province city region4 hu_line cii pat_app pat_grant sci_exp ///
      college market hukou_pop pat_grant_pc
compress
save "data/panel_cii_2000_2024.dta", replace

di _newline "========== Panel construction complete =========="
count
di "Full-sample observations = " r(N)
summarize cii
