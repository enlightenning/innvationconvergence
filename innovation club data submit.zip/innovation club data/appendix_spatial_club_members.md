## Appendix: List of Spatial Club Members (growth-spatial integration)

> 13 spatial clubs in total, 274 cities; each club is centered on a growth pole.

**Spatial Club 1** (43 cities, growth pole: Beijing): Beijing, Tianjin, Shijiazhuang, Harbin, Shenyang, Changchun, Baoding, Tangshan, Hohhot, Langfang, Qinhuangdao, Baotou, Jilin, Anshan, Daqing, Zhangjiakou, Jinzhou, Chengde, Mudanjiang, Jiamusi, Yingkou, Datong, Fushun, Chifeng, Fuxin, Ulanqab, Tongliao, Panjin, Siping, Shuozhou, Tieling, Liaoyang, Xinzhou, Huludao, Chaoyang, Liaoyuan, Jixi, Songyuan, Heihe, Shuangyashan, Baicheng, Qitaihe, Yichun

**Spatial Club 2** (38 cities, growth pole: Shenzhen): Shenzhen, Guangzhou, Foshan, Dongguan, Xiamen, Quanzhou, Nanning, Zhongshan, Zhuhai, Ganzhou, Huizhou, Shantou, Jiangmen, Haikou, Zhangzhou, Zhaoqing, Zhanjiang, Chaozhou, Jieyang, Sanya, Longyan, Maoming, Putian, Qingyuan, Yulin, Yangjiang, Beihai, Shaoguan, Wuzhou, Qinzhou, Shanwei, Meizhou, Heyuan, Guigang, Yunfu, Laibin, Hezhou, Fangchenggang

**Spatial Club 3** (20 cities, growth pole: Shanghai): Shanghai, Suzhou, Hangzhou, Ningbo, Wuxi, Changzhou, Wenzhou, Nantong, Fuzhou, Jiaxing, Jinhua, Shaoxing, Taizhou, Yancheng, Huzhou, Taizhou, Lishui, Quzhou, Ningde, Zhoushan

**Spatial Club 4** (15 cities, growth pole: Wuhan): Wuhan, Nanchang, Jiujiang, Yichang, Jingzhou, Xiangyang, Xinyang, Huanggang, Huangshi, Xiaogan, Jingmen, Xianning, Ezhou, Yingtan, Suizhou

**Spatial Club 5** (15 cities, growth pole: Chengdu): Chengdu, Mianyang, Urumqi, Deyang, Xining, Yibin, Zigong, Leshan, Neijiang, Karamay, Suining, Ya'an, Ziyang, Jiuquan, Guangyuan

**Spatial Club 6** (24 cities, growth pole: Hefei): Hefei, Nanjing, Wuhu, Xuzhou, Yangzhou, Zhenjiang, Huai'an, Ma'anshan, Chuzhou, Suqian, Bengbu, Fuyang, Anqing, Shangrao, Lu'an, Xuancheng, Huainan, Tongling, Suzhou, Jingdezhen, Huaibei, Chizhou, Bozhou, Huangshan

**Spatial Club 7** (7 cities, growth pole: Chongqing): Chongqing, Guiyang, Zunyi, Luzhou, Dazhou, Guang'an, Bazhong

**Spatial Club 8** (20 cities, growth pole: Zhengzhou): Zhengzhou, Taiyuan, Luoyang, Xinxiang, Nanyang, Shangqiu, Anyang, Jiaozuo, Zhumadian, Xuchang, Kaifeng, Pingdingshan, Zhoukou, Luohe, Sanmenxia, Changzhi, Hebi, Jincheng, Linfen, Lüliang

**Spatial Club 9** (29 cities, growth pole: Xi'an): Xi'an, Lanzhou, Yinchuan, Xianyang, Shiyan, Yulin, Ordos, Baoji, Yuncheng, Hanzhong, Weinan, Tianshui, Wuzhong, Yan'an, Shizuishan, Jiayuguan, Zhangye, Pingliang, Jinchang, Qingyang, Ankang, Wuwei, Baiyin, Bayannur, Wuhai, Shangluo, Guyuan, Dingxi, Tongchuan

**Spatial Club 10** (22 cities, growth pole: Changsha): Changsha, Guilin, Zhuzhou, Xiangtan, Hengyang, Yichun, Ji'an, Liuzhou, Yueyang, Chenzhou, Changde, Fuzhou, Yiyang, Shaoyang, Yongzhou, Nanping, Sanming, Xinyu, Huaihua, Pingxiang, Loudi, Zhangjiajie

**Spatial Club 11** (11 cities, growth pole: Qingdao): Qingdao, Weifang, Dalian, Yantai, Weihai, Rizhao, Lianyungang, Dandong, Benxi, Tonghua, Baishan

**Spatial Club 12** (16 cities, growth pole: Jinan): Jinan, Zibo, Linyi, Jining, Tai'an, Dezhou, Cangzhou, Handan, Xingtai, Binzhou, Liaocheng, Heze, Dongying, Zaozhuang, Hengshui, Puyang

**Spatial Club 13** (14 cities, growth pole: Kunming): Kunming, Chongzuo, Baise, Yuxi, Qujing, Panzhihua, Anshun, Hechi, Liupanshui, Baoshan, Lijiang, Zhaotong, Pu'er, Lincang

