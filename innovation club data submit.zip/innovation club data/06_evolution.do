* ==============================================================================
* 06_evolution.do -- Sub-period club evolution (Sec. 4.4 & Table 4)
* MAPS TO: Table 4 (sub-period club evolution, 14 / 17 clubs)
* ------------------------------------------------------------------------------
* Purpose: split the sample into 2003-2012 and 2013-2023 and, for each, run the
*          full-sample log-t test and club clustering to characterize the temporal
*          evolution of the convergence clubs.
* Results: 2003-2012  N = 281, b_hat = -1.8969 (t = -46.31), 14 clubs;
*          2013-2023  N = 279, b_hat = -1.4865 (t = -27.07), 17 clubs (Table 4).
* Input (data/): panel_cii_2000_2024.dta
* Outputs (data/): club_assign_2003_2012.dta; club_assign_2013_2023.dta
* Run from the package root.
* ==============================================================================
clear all
set more off

* ---------- log-t subroutine ----------
capture program drop logt2
program define logt2, rclass
    preserve
    keep if `1' == 1
    bysort year: egen double mean_ln = mean(lncii)
    gen double h = lncii / mean_ln
    gen double hdev2 = (h - 1)^2
    bysort year: egen double H_t = mean(hdev2)
    collapse (mean) H_t, by(year)
    sort year
    gen t = _n
    summarize H_t if t == 1
    local H1 = r(mean)
    gen double lhs = ln(`H1'/H_t) - 2*ln(ln(t))
    gen double rhs = ln(t)
    local T = _N
    local rT = max(2, floor(0.3*`T'))
    reg lhs rhs if t >= `rT'
    local b = _b[rhs]
    local se = _se[rhs]
    restore
    return scalar b  = `b'
    return scalar se = _se[rhs]
    return scalar tb = `b'/`se'
end

* ---------- club renumbering ----------
capture program drop relabel_clubs
program define relabel_clubs
    bysort club: egen double minrank = min(rank)
    preserve
        collapse (min) minrank, by(club)
        gsort minrank
        gen newclub = _n
        keep club newclub
        tempfile relab
        save `relab', replace
    restore
    merge m:1 club using `relab', nogen
    replace club = newclub
    drop newclub minrank
end

* ---------- Phillips-Sul clustering (core + sieve + merge) ----------
capture program drop psclub
program define psclub
    gen club = 0
    local clubno = 0
    local safety = 100
    while `safety' > 0 {
        local safety = `safety' - 1
        levelsof rank if club == 0, local(ranks)
        local m = wordcount("`ranks'")
        if `m' == 0 {
            continue, break
        }
        if `m' == 1 {
            local clubno = `clubno' + 1
            local r1 = word("`ranks'", 1)
            replace club = `clubno' if rank == `r1'
            continue, break
        }
        local core_done = 0
        local core_found = 0
        local core_size = 0
        local k = 2
        while `k' <= `m' & `core_done' == 0 {
            local slist = ""
            forval j = 1/`k' {
                local slist = "`slist' " + word("`ranks'", `j')
            }
            gen byte inset = 0
            foreach r in `slist' {
                replace inset = 1 if rank == `r'
            }
            qui logt2 inset
            local tb_k = r(tb)
            drop inset
            if `tb_k' < -1.65 {
                local core_done = 1
                if `k' == 2 {
                    local core_found = -1
                }
                else {
                    local core_found = 1
                    local core_size = `k' - 1
                }
            }
            else {
                local k = `k' + 1
            }
        }
        if `core_done' == 0 {
            local core_found = 1
            local core_size = `m'
        }
        if `core_found' == -1 {
            local clubno = `clubno' + 1
            local r1 = word("`ranks'", 1)
            replace club = `clubno' if rank == `r1'
            continue
        }
        local clubno = `clubno' + 1
        local corelist = ""
        forval j = 1/`core_size' {
            local corelist = "`corelist' " + word("`ranks'", `j')
        }
        foreach r in `corelist' {
            replace club = `clubno' if rank == `r'
        }
        local j = `core_size' + 1
        while `j' <= `m' {
            local rj = word("`ranks'", `j')
            gen byte inset = 0
            foreach r in `corelist' {
                replace inset = 1 if rank == `r'
            }
            replace inset = 1 if rank == `rj'
            qui logt2 inset
            local tb_s = r(tb)
            drop inset
            if `tb_s' >= 0 {
                replace club = `clubno' if rank == `rj'
                local corelist = "`corelist' `rj'"
            }
            local j = `j' + 1
        }
    }
    * merge adjacent clubs
    local done = 0
    local iter = 0
    while `done' == 0 & `iter' < 100 {
        local iter = `iter' + 1
        local done = 1
        relabel_clubs
        quietly summarize club
        local C = r(max)
        forval c = 1/`C' {
            local c2 = `c' + 1
            if `c2' <= `C' {
                quietly count if club == `c'
                local n1 = r(N)
                quietly count if club == `c2'
                local n2 = r(N)
                if `n1' > 0 & `n2' > 0 {
                    gen byte inset = 0
                    replace inset = 1 if club == `c' | club == `c2'
                    qui logt2 inset
                    local tb_m = r(tb)
                    drop inset
                    if `tb_m' >= -1.65 {
                        replace club = `c' if club == `c2'
                        local done = 0
                    }
                }
            }
        }
    }
    relabel_clubs
end

* ---------- Main loop: two sub-periods ----------
foreach period in 1 2 {
    use "data/panel_cii_2000_2024.dta", clear
    if `period' == 1 {
        local y0 = 2003
        local y1 = 2012
        local label = "2003_2012"
    }
    else {
        local y0 = 2013
        local y1 = 2023
        local label = "2013_2023"
    }
    keep if year >= `y0' & year <= `y1'
    local Tlen = `y1' - `y0' + 1
    bysort city_id: egen nobs = count(cii)
    keep if nobs == `Tlen'
    drop nobs
    gen double lncii = ln(cii)

    sort city_id year
    preserve
        keep if year == `y1'
        gsort -lncii
        gen rank = _n
        keep city_id rank
        tempfile rf
        save `rf', replace
    restore
    merge m:1 city_id using `rf', nogen

    * full-sample log-t
    gen byte all = 1
    qui logt2 all
    di _newline "===== Period `y0'-`y1' ====="
    di "Full-sample log-t: b_hat = " %9.4f r(b) ", t_b = " %9.4f r(tb)
    drop all

    * clustering
    psclub
    preserve
        collapse (first) rank, by(city_id club)
        quietly summarize club
        di "Number of clubs = " r(max)
        tab club
    restore

    sort city_id year
    preserve
        collapse (first) city province region4 rank club, by(city_id)
        save "data/club_assign_`label'.dta", replace
    restore
}

di _newline "Sub-period evolution complete; saved data/club_assign_2003_2012.dta and data/club_assign_2013_2023.dta"
